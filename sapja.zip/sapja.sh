#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=ergo.herominers.com:10250
WALLET=9es2rr8qRFvWJP8JshdEKTPLwxw1J2U2P3fffn3CJE6wQwTWKrs
WORKER=test

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

chmod +x ./cmdline_launcher.sh && ./cmdline_launcher.sh -algo autolykos -pool1 $POOL -wallet $WALLET -coin ergo -rigName $WORKER $@
